package com.example.moviecatalog.domain.model

data class SourceSearchResult(
    val title: String,
    val url: String,
    val year: String?,
    val poster: String?,
    val sourceName: String
)
