package com.example.moviecatalog.ui.screens.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moviecatalog.data.scraper.SourceManager
import com.example.moviecatalog.domain.model.SourceLoadStatus
import com.example.moviecatalog.domain.model.SourceStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SourcePickerViewModel @Inject constructor(
    private val sourceManager: SourceManager
) : ViewModel() {

    private val _sources = MutableStateFlow<List<SourceStatus>>(emptyList())
    val sources: StateFlow<List<SourceStatus>> = _sources.asStateFlow()

    fun searchSources(query: String) {
        viewModelScope.launch {
            // Ініціалізуємо всі джерела як LOADING
            val initialStatuses = sourceManager.getProviderNames().map { name ->
                SourceStatus(name, SourceLoadStatus.LOADING)
            }
            _sources.value = initialStatuses

            // Перевіряємо кожне джерело
            sourceManager.getProviderNames().forEach { sourceName ->
                try {
                    val streams = sourceManager.resolveFromSource(sourceName, query)
                    if (streams.isNotEmpty()) {
                        updateSource(sourceName, SourceLoadStatus.AVAILABLE, streams)
                    } else {
                        updateSource(sourceName, SourceLoadStatus.UNAVAILABLE)
                    }
                } catch (e: Exception) {
                    updateSource(sourceName, SourceLoadStatus.ERROR)
                }
            }
        }
    }

    fun resolveStreams(sourceName: String, query: String) {
        viewModelScope.launch {
            updateSource(sourceName, SourceLoadStatus.LOADING)
            try {
                val streams = sourceManager.resolveFromSource(sourceName, query)
                if (streams.isNotEmpty()) {
                    updateSource(sourceName, SourceLoadStatus.AVAILABLE, streams)
                } else {
                    updateSource(sourceName, SourceLoadStatus.UNAVAILABLE)
                }
            } catch (e: Exception) {
                updateSource(sourceName, SourceLoadStatus.ERROR)
            }
        }
    }

    private fun updateSource(
        name: String,
        status: SourceLoadStatus,
        streams: List<com.example.moviecatalog.domain.model.StreamOption> = emptyList()
    ) {
        _sources.value = _sources.value.map {
            if (it.sourceName == name) it.copy(status = status, streams = streams) else it
        }
    }
}
