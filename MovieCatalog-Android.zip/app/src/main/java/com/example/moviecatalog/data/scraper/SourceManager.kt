package com.example.moviecatalog.data.scraper

import com.example.moviecatalog.data.scraper.providers.*
import com.example.moviecatalog.domain.model.SourceSearchResult
import com.example.moviecatalog.domain.model.SourceStatus
import com.example.moviecatalog.domain.model.SourceLoadStatus
import com.example.moviecatalog.domain.model.StreamOption
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.OkHttpClient
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SourceManager @Inject constructor(
    private val httpClient: OkHttpClient,
    private val extractor: UniversalMediaExtractor
) {
    private val providers: List<SourceProvider> by lazy {
        listOf(
            UakinoProvider(httpClient, extractor),
            HdrezkaProvider(httpClient, extractor),
            KodikProvider(httpClient, extractor),
            AllohaProvider(httpClient, extractor),
            GenericProvider(httpClient, extractor, "Collaps", "https://collaps.info"),
            GenericProvider(httpClient, extractor, "HDVB", "https://hdvb.tv"),
            GenericProvider(httpClient, extractor, "VideoCDN", "https://videocdn.tv"),
            GenericProvider(httpClient, extractor, "Kinokong", "https://kinokong.pro"),
            GenericProvider(httpClient, extractor, "Filmix", "https://filmix.gg"),
            GenericProvider(httpClient, extractor, "UASerials", "https://uaserials.com"),
            GenericProvider(httpClient, extractor, "KinoKrad", "https://kinokrad.im"),
            GenericProvider(httpClient, extractor, "UAfix", "https://uafix.net"),
            GenericProvider(httpClient, extractor, "UAKinoGo", "https://uakinogo.io"),
            GenericProvider(httpClient, extractor, "KinoVasek", "https://kinovasek.net"),
            GenericProvider(httpClient, extractor, "Eneyida", "https://eneyida.tv"),
            GenericProvider(httpClient, extractor, "KinoBar", "https://kinobar.im"),
            GenericProvider(httpClient, extractor, "KinoVibe", "https://kinovibe.cc"),
            GenericProvider(httpClient, extractor, "Kinogram", "https://kinogram.pro"),
            GenericProvider(httpClient, extractor, "CDN VideoHub", "https://cdn.videohub.top"),
            GenericProvider(httpClient, extractor, "Ashdi", "https://ashdi.tv"),
            GenericProvider(httpClient, extractor, "Videocdn", "https://videocdn.cc")
        )
    }

    fun searchAllSources(query: String): Flow<SourceStatus> = flow {
        coroutineScope {
            providers.map { provider ->
                async {
                    try {
                        emit(SourceStatus(provider.name, SourceLoadStatus.LOADING))
                        val results = provider.search(query)
                        if (results.isNotEmpty()) {
                            emit(SourceStatus(provider.name, SourceLoadStatus.AVAILABLE))
                        } else {
                            emit(SourceStatus(provider.name, SourceLoadStatus.UNAVAILABLE))
                        }
                    } catch (e: Exception) {
                        Timber.e(e, "${provider.name}: помилка пошуку")
                        emit(SourceStatus(provider.name, SourceLoadStatus.ERROR))
                    }
                }
            }.awaitAll()
        }
    }

    suspend fun resolveFromSource(sourceName: String, query: String): List<StreamOption> {
        val provider = providers.find { it.name == sourceName } ?: return emptyList()
        val results = provider.search(query)
        if (results.isEmpty()) return emptyList()

        // Беремо перший результат та витягуємо стріми
        val firstResult = results.first()
        return provider.resolveStreams(firstResult.url)
    }

    suspend fun resolveFromUrl(sourceName: String, url: String): List<StreamOption> {
        val provider = providers.find { it.name == sourceName } ?: return emptyList()
        return provider.resolveStreams(url)
    }

    fun getProviderNames(): List<String> = providers.map { it.name }
}
