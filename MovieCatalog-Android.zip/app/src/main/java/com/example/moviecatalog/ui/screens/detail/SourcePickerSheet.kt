package com.example.moviecatalog.ui.screens.detail

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SourcePickerSheet(
    title: String,
    onDismiss: () -> Unit,
    onStreamSelected: (String) -> Unit,
    viewModel: SourcePickerViewModel = hiltViewModel()
) {
    val sheetState = rememberModalBottomSheetState()
    val sources by viewModel.sources.collectAsState()

    LaunchedEffect(title) {
        viewModel.searchSources(title)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Оберіть джерело",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sources) { source ->
                    SourceItem(
                        name = source.sourceName,
                        status = source.status,
                        onClick = {
                            if (source.streams.isNotEmpty()) {
                                onStreamSelected(source.streams.first().url)
                            } else {
                                viewModel.resolveStreams(source.sourceName, title)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SourceItem(
    name: String,
    status: com.example.moviecatalog.domain.model.SourceLoadStatus,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val icon = when (status) {
                    com.example.moviecatalog.domain.model.SourceLoadStatus.LOADING -> Icons.Default.Refresh
                    com.example.moviecatalog.domain.model.SourceLoadStatus.AVAILABLE -> Icons.Default.CheckCircle
                    com.example.moviecatalog.domain.model.SourceLoadStatus.ERROR -> Icons.Default.Error
                    com.example.moviecatalog.domain.model.SourceLoadStatus.UNAVAILABLE -> Icons.Default.Cancel
                }
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = name, style = MaterialTheme.typography.bodyLarge)
            }

            val statusText = when (status) {
                com.example.moviecatalog.domain.model.SourceLoadStatus.LOADING -> "⟳"
                com.example.moviecatalog.domain.model.SourceLoadStatus.AVAILABLE -> "✓"
                com.example.moviecatalog.domain.model.SourceLoadStatus.ERROR -> "✗"
                com.example.moviecatalog.domain.model.SourceLoadStatus.UNAVAILABLE -> "—"
            }
            Text(text = statusText, style = MaterialTheme.typography.titleMedium)
        }
    }
}
