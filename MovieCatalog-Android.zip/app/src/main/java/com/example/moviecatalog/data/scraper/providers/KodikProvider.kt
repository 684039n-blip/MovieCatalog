package com.example.moviecatalog.data.scraper.providers

import com.example.moviecatalog.data.scraper.SourceProvider
import com.example.moviecatalog.data.scraper.UniversalMediaExtractor
import com.example.moviecatalog.domain.model.SourceSearchResult
import com.example.moviecatalog.domain.model.StreamOption
import com.example.moviecatalog.domain.model.StreamType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import javax.inject.Inject

/**
 * Kodik — балансир. Має API для пошуку та вбудований плеєр з HLS.
 * Базовий URL: https://kodik.biz
 */
class KodikProvider @Inject constructor(
    private val httpClient: OkHttpClient,
    private val extractor: UniversalMediaExtractor
) : SourceProvider {
    override val name = "Kodik"
    override val baseUrl = "https://kodik.biz"

    override suspend fun search(query: String): List<SourceSearchResult> = withContext(Dispatchers.IO) {
        try {
            val searchUrl = "$baseUrl/search?title=$query"
            val request = Request.Builder().url(searchUrl)
                .header("User-Agent", "Mozilla/5.0 Chrome/120.0.0.0")
                .build()
            val html = httpClient.newCall(request).execute().use { it.body?.string() ?: return@withContext emptyList() }
            val doc = Jsoup.parse(html)
            doc.select("table.table tbody tr").mapNotNull { row ->
                val title = row.select("td a").first()?.text() ?: return@mapNotNull null
                val href = row.select("td a").attr("href")
                val year = row.select("td").getOrNull(2)?.text()
                if (href.isNotEmpty()) {
                    SourceSearchResult(title, href, year, null, name)
                } else null
            }
        } catch (e: Exception) {
            Timber.e(e, "Kodik: помилка пошуку")
            emptyList()
        }
    }

    override suspend fun resolveStreams(url: String): List<StreamOption> = withContext(Dispatchers.IO) {
        try {
            // Kodik зазвичай має iframe з плеєром, який містить m3u8
            val request = Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 Chrome/120.0.0.0")
                .build()
            val html = httpClient.newCall(request).execute().use { it.body?.string() ?: return@withContext emptyList() }

            // Шукаємо iframe з плеєром Kodik
            val doc = Jsoup.parse(html)
            val iframeSrc = doc.select("iframe").attr("src")
            if (iframeSrc.isNotEmpty()) {
                return@withContext extractor.extract(iframeSrc, name)
            }

            // Шукаємо прямі m3u8
            val m3u8Regex = Regex("""https?://[^\s"']+\.m3u8[^\s"']*""")
            m3u8Regex.findAll(html).map { match ->
                StreamOption(
                    url = match.value,
                    quality = Regex("""(\d{3,4})p""").find(match.value)?.value,
                    language = "uk",
                    type = StreamType.HLS,
                    sourceName = name
                )
            }.toList()
        } catch (e: Exception) {
            Timber.e(e, "Kodik: помилка resolveStreams")
            emptyList()
        }
    }
}
