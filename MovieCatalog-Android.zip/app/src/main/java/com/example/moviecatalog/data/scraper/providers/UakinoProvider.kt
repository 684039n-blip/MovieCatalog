package com.example.moviecatalog.data.scraper.providers

import com.example.moviecatalog.data.scraper.SourceProvider
import com.example.moviecatalog.data.scraper.UniversalMediaExtractor
import com.example.moviecatalog.domain.model.SourceSearchResult
import com.example.moviecatalog.domain.model.StreamOption
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import timber.log.Timber
import javax.inject.Inject

/**
 * Парсер для uakino.best — український онлайн-кінотеатр
 */
class UakinoProvider @Inject constructor(
    private val httpClient: OkHttpClient,
    private val extractor: UniversalMediaExtractor
) : SourceProvider {
    override val name = "UAKino"
    override val baseUrl = "https://uakino.best"

    override suspend fun search(query: String): List<SourceSearchResult> = withContext(Dispatchers.IO) {
        try {
            val searchUrl = "$baseUrl/index.php?do=search&subaction=search&story=$query"
            val request = Request.Builder().url(searchUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) Chrome/120.0.0.0 Mobile")
                .build()
            val html = httpClient.newCall(request).execute().use { it.body?.string() ?: return@withContext emptyList() }
            val doc = Jsoup.parse(html)
            doc.select("div.movie-item, div.shortstory").mapNotNull { element ->
                val title = element.select("a").attr("title").ifEmpty { element.select("a").text() }
                val href = element.select("a").attr("href")
                val poster = element.select("img").attr("src")
                val year = element.select(".year, .date").text().take(4)
                if (title.isNotEmpty() && href.isNotEmpty()) {
                    SourceSearchResult(title, href, year, poster, name)
                } else null
            }
        } catch (e: Exception) {
            Timber.e(e, "UAKino: помилка пошуку")
            emptyList()
        }
    }

    override suspend fun resolveStreams(url: String): List<StreamOption> {
        return extractor.extract(url, name)
    }
}
