package com.example.moviecatalog.data.scraper

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Обхід Cloudflare / DDoS-Guard через прихований WebView.
 * Використовується коли OkHttp отримує 403/503.
 */
@Singleton
class CloudflareBypass @Inject constructor() {

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun bypassWithWebView(
        webView: WebView,
        url: String,
        timeoutMs: Long = 30_000L
    ): String? {
        return try {
            withTimeout(timeoutMs) {
                suspendCancellableCoroutine { continuation ->
                    webView.settings.javaScriptEnabled = true
                    webView.settings.domStorageEnabled = true
                    webView.settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"

                    webView.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                            super.onPageFinished(view, finishedUrl)
                            // Даємо час на виконання JS-челенджу
                            view?.postDelayed({
                                val cookies = android.webkit.CookieManager.getInstance()
                                    .getCookie(finishedUrl ?: url)
                                continuation.resumeWith(Result.success(cookies))
                            }, 5000)
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            errorCode: Int,
                            description: String?,
                            failingUrl: String?
                        ) {
                            Timber.w("WebView помилка: $description")
                        }
                    }

                    webView.loadUrl(url)

                    continuation.invokeOnCancellation {
                        webView.stopLoading()
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Помилка обходу Cloudflare для $url")
            null
        }
    }

    /**
     * Перехоплення медіа-запитів через WebView
     */
    fun createMediaInterceptingClient(
        onMediaFound: (String) -> Unit
    ): WebViewClient {
        return object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()
                if (url.endsWith(".m3u8") || url.endsWith(".mp4") ||
                    url.endsWith(".mpd") || url.endsWith(".webm")
                ) {
                    Timber.d("Перехоплено медіа-запит: $url")
                    onMediaFound(url)
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
    }
}
