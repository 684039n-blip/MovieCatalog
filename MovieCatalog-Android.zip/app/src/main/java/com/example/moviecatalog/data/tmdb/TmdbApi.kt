package com.example.moviecatalog.data.tmdb

import com.example.moviecatalog.data.tmdb.dto.*
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface TmdbApi {

    @GET("trending/all/week")
    suspend fun getTrending(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("movie/popular")
    suspend fun getPopularMovies(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("movie/top_rated")
    suspend fun getTopRatedMovies(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("movie/now_playing")
    suspend fun getNowPlayingMovies(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("movie/upcoming")
    suspend fun getUpcomingMovies(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("tv/popular")
    suspend fun getPopularTv(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("tv/top_rated")
    suspend fun getTopRatedTv(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("tv/on_the_air")
    suspend fun getOnTheAirTv(
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("discover/movie")
    suspend fun discoverMovies(
        @Query("with_genres") genres: String? = null,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("discover/tv")
    suspend fun discoverTv(
        @Query("with_genres") genres: String? = null,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse

    @GET("genre/movie/list")
    suspend fun getMovieGenres(
        @Query("language") language: String = "uk-UA"
    ): TmdbGenresResponse

    @GET("genre/tv/list")
    suspend fun getTvGenres(
        @Query("language") language: String = "uk-UA"
    ): TmdbGenresResponse

    @GET("movie/{movie_id}")
    suspend fun getMovieDetails(
        @Path("movie_id") movieId: Int,
        @Query("append_to_response") appendToResponse: String = "credits,similar,images",
        @Query("language") language: String = "uk-UA"
    ): TmdbMovieDetailResponse

    @GET("tv/{tv_id}")
    suspend fun getTvDetails(
        @Path("tv_id") tvId: Int,
        @Query("append_to_response") appendToResponse: String = "credits,similar,images",
        @Query("language") language: String = "uk-UA"
    ): TmdbTvDetailResponse

    @GET("search/multi")
    suspend fun searchMulti(
        @Query("query") query: String,
        @Query("language") language: String = "uk-UA",
        @Query("page") page: Int = 1
    ): TmdbPageResponse
}
