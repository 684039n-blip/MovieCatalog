# MovieCatalog

Android медіа-каталог з TMDB API та Media3 плеєром.